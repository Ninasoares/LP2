﻿namespace Triangulos
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.ladoa = new System.Windows.Forms.Label();
            this.ladob = new System.Windows.Forms.Label();
            this.ladoc = new System.Windows.Forms.Label();
            this.lbl_res = new System.Windows.Forms.Label();
            this.txt_b = new System.Windows.Forms.TextBox();
            this.txt_a = new System.Windows.Forms.TextBox();
            this.txt_c = new System.Windows.Forms.TextBox();
            this.calcular = new System.Windows.Forms.Button();
            this.limpar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // ladoa
            // 
            this.ladoa.AutoSize = true;
            this.ladoa.Font = new System.Drawing.Font("Rockwell", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ladoa.Location = new System.Drawing.Point(31, 63);
            this.ladoa.Name = "ladoa";
            this.ladoa.Size = new System.Drawing.Size(71, 21);
            this.ladoa.TabIndex = 0;
            this.ladoa.Text = "Lado A";
            // 
            // ladob
            // 
            this.ladob.AutoSize = true;
            this.ladob.Font = new System.Drawing.Font("Rockwell", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ladob.Location = new System.Drawing.Point(31, 110);
            this.ladob.Name = "ladob";
            this.ladob.Size = new System.Drawing.Size(69, 21);
            this.ladob.TabIndex = 1;
            this.ladob.Text = "Lado B";
            // 
            // ladoc
            // 
            this.ladoc.AutoSize = true;
            this.ladoc.Font = new System.Drawing.Font("Rockwell", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ladoc.Location = new System.Drawing.Point(33, 153);
            this.ladoc.Name = "ladoc";
            this.ladoc.Size = new System.Drawing.Size(72, 21);
            this.ladoc.TabIndex = 2;
            this.ladoc.Text = "Lado C";
            // 
            // lbl_res
            // 
            this.lbl_res.AutoSize = true;
            this.lbl_res.Font = new System.Drawing.Font("Rockwell", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_res.Location = new System.Drawing.Point(108, 21);
            this.lbl_res.Name = "lbl_res";
            this.lbl_res.Size = new System.Drawing.Size(96, 21);
            this.lbl_res.TabIndex = 3;
            this.lbl_res.Text = "Triangulo";
            // 
            // txt_b
            // 
            this.txt_b.Font = new System.Drawing.Font("Rockwell", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_b.Location = new System.Drawing.Point(135, 101);
            this.txt_b.Name = "txt_b";
            this.txt_b.Size = new System.Drawing.Size(168, 30);
            this.txt_b.TabIndex = 4;
            // 
            // txt_a
            // 
            this.txt_a.Font = new System.Drawing.Font("Rockwell", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_a.Location = new System.Drawing.Point(135, 60);
            this.txt_a.Name = "txt_a";
            this.txt_a.Size = new System.Drawing.Size(168, 30);
            this.txt_a.TabIndex = 5;
            // 
            // txt_c
            // 
            this.txt_c.Font = new System.Drawing.Font("Rockwell", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_c.Location = new System.Drawing.Point(135, 150);
            this.txt_c.Name = "txt_c";
            this.txt_c.Size = new System.Drawing.Size(168, 30);
            this.txt_c.TabIndex = 6;
            // 
            // calcular
            // 
            this.calcular.Font = new System.Drawing.Font("Rockwell", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.calcular.Location = new System.Drawing.Point(23, 199);
            this.calcular.Name = "calcular";
            this.calcular.Size = new System.Drawing.Size(118, 46);
            this.calcular.TabIndex = 7;
            this.calcular.Text = "Calcular";
            this.calcular.UseVisualStyleBackColor = true;
            this.calcular.Click += new System.EventHandler(this.calcular_Click_1);
            // 
            // limpar
            // 
            this.limpar.Font = new System.Drawing.Font("Rockwell", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.limpar.Location = new System.Drawing.Point(177, 199);
            this.limpar.Name = "limpar";
            this.limpar.Size = new System.Drawing.Size(126, 46);
            this.limpar.TabIndex = 9;
            this.limpar.Text = "Limpar";
            this.limpar.UseVisualStyleBackColor = true;
            this.limpar.Click += new System.EventHandler(this.limpar_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(331, 268);
            this.Controls.Add(this.limpar);
            this.Controls.Add(this.calcular);
            this.Controls.Add(this.txt_c);
            this.Controls.Add(this.txt_a);
            this.Controls.Add(this.txt_b);
            this.Controls.Add(this.lbl_res);
            this.Controls.Add(this.ladoc);
            this.Controls.Add(this.ladob);
            this.Controls.Add(this.ladoa);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label ladoa;
        private System.Windows.Forms.Label ladob;
        private System.Windows.Forms.Label ladoc;
        private System.Windows.Forms.Label lbl_res;
        private System.Windows.Forms.TextBox txt_b;
        private System.Windows.Forms.TextBox txt_a;
        private System.Windows.Forms.TextBox txt_c;
        private System.Windows.Forms.Button calcular;
        private System.Windows.Forms.Button limpar;
    }
}

