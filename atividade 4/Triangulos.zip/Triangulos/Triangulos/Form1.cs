﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Triangulos
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        
        private void calcular_Click_1(object sender, EventArgs e)
        {
            double a, b, c;
            string resu;

            if (double.TryParse(txt_a, out a)&&
                              (txt_b, out b)&&
                              (txt_c, out c))
            {
                if (a = 0 || b = 0 || c = 0)
                    MessageBox.Show("VALOR INVALIDO");

                else if (a = b && a = c && b = c)
                    lbl_res.Text += ("TRINGULO EQUILATERO");

                if (a = b || a = c || b = c)
                    lbl_res += ("TRIANGULO ISOSCELES");

                else
                    lbl_res += ("TRIANGULO ESCALENO");
            }


        }

        private void limpar_Click(object sender, EventArgs e)
        {
            txt_a.Text += "";
            txt_b.Text += "";
            txt_c.Text += "";
        }
    }
}
