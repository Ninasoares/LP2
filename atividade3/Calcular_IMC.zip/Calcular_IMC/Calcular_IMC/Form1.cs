﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calcular_IMC
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calcular_Click(object sender, EventArgs e)
        {
            Double altura, peso, imc;
            peso = double.Parse(txt_peso.Text);
            altura = double.Parse(txt_altura.Text);
            imc = peso / (altura * altura);

            if (imc < 18.5)
            {
                lbl_imc.Text += "Magreza";
            }

            if (imc = 18.5 && imc <= 24.9)
            {
                lbl_imc.Text += "Normal";
            }

            if (imc >= 25 && imc <= 29.9) 
            {
                lbl_imc.Text += "Sobrepeso Grau:1 ";
            }


            if (imc >= 30 && imc <= 39.9) 
            {
                lbl_imc.Text += "Obesidade Grau:2 ";
            }

            if (imc >= 40)
            {
                lbl_imc.Text += "Obesidade Grave Grau:3 ";
            }

            txt_altura.Text = "";
            txt_peso.Text = "";


        }



    }
}
   

