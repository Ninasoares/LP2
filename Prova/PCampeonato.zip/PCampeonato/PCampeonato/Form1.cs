﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PCampeonato
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnexecutar_Click(object sender, EventArgs e)
        {
            // último digito do RA Ana = 5

            int[,] golfeito = new int[5, 3];
            int[] Tgol = new int[5];
            int[] Tgolrecebido = new int[5];
            int[] Tgolsaldo = new int[5];
            string gols;
            int totalgols = 0;
            int totalrecebido = 0;


            for (int x = 0; x < 5; x++)
            {
                gols = Interaction.InputBox("Digite a quantidade de gols feitos do time " + (x + 1), "Entrada de dados");
                if (gols == "")
                {
                    MessageBox.Show("Valor Invalido");
                    x--;
                }
                else if (int.TryParse(gols, out golfeito[x, 0]))
                {
                    int.TryParse(gols, out golfeito[x, 0]);
                }
                else
                {
                    MessageBox.Show("Digite apenas números!");
                    x--;
                }
            }

            for (int x = 0; x < 5; x++)
            {
                gols = Interaction.InputBox("Digite a quantidade de gols recebidos do time " + (x + 1), "Entrada de dados");
                if (gols == "")
                {
                    MessageBox.Show("Valor Invalido");
                    x--;
                }
                else if (int.TryParse(gols, out golfeito[x, 1]))
                {
                    int.TryParse(gols, out golfeito[x, 1]);
                }
                else
                {
                    MessageBox.Show("Digite apenas números!");
                    x--;
                }
            }

            for (int x = 0; x < 5; x++)
            {
                gols = Interaction.InputBox("Digite a quantidade de saldos dos gols do time " + (x + 1), "Entrada de dados");
                if (gols == "")
                {
                    MessageBox.Show("Valor Invalido");
                    x--;
                }
                else if (int.TryParse(gols, out golfeito[x, 2]))
                {
                    int.TryParse(gols, out golfeito[x, 2]);
                }
                else
                {
                    MessageBox.Show("Digite apenas números!");
                    x--;
                }
            }
            for (int x = 0; x < 5; x++)
            {
                for (int y = 0; y < 3; y++)
                {
                    Tgol[x] = Tgol[x] + golfeito[x, y];
                }

                totalgols = totalgols + Tgol[x];
            }

            for (int x = 0; x < 5; x++)
            {
                Tgolrecebido[x] = Tgolrecebido[x] + golfeito[x, 1];
                totalrecebido = totalrecebido + Tgolrecebido[x];
            }


            for (int x = 0; x < 5; x++)
            {
                Tgolsaldo[x] = Tgolsaldo[x] + golfeito[x, 2];
            }


            for (int x = 0; x < 5; x++)
            {

                ltbresultados.Items.Add("Time " + (x + 1) + "  Gols feitos: " + Tgol[x].ToString("N2") + "  Gols recebidos: " + Tgolrecebido[x].ToString("N2") + "  Saldo de gols: " + Tgolsaldo[x].ToString("N2"));
            }
            ltbresultados.Items.Add("¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨¨");
            ltbresultados.Items.Add(" Total de gols feitos:  " + totalgols.ToString("N2"));
            ltbresultados.Items.Add(" Total gols recebidos: " + totalrecebido.ToString("N2"));
        }
    }
}

            


           

