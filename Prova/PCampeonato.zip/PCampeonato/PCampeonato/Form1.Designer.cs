﻿namespace PCampeonato
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnexecutar = new System.Windows.Forms.Button();
            this.ltbresultados = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btnexecutar
            // 
            this.btnexecutar.Font = new System.Drawing.Font("Showcard Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnexecutar.Location = new System.Drawing.Point(12, 12);
            this.btnexecutar.Name = "btnexecutar";
            this.btnexecutar.Size = new System.Drawing.Size(445, 149);
            this.btnexecutar.TabIndex = 0;
            this.btnexecutar.Text = "Executar";
            this.btnexecutar.UseVisualStyleBackColor = true;
            this.btnexecutar.Click += new System.EventHandler(this.btnexecutar_Click);
            // 
            // ltbresultados
            // 
            this.ltbresultados.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ltbresultados.FormattingEnabled = true;
            this.ltbresultados.ItemHeight = 19;
            this.ltbresultados.Location = new System.Drawing.Point(12, 186);
            this.ltbresultados.Name = "ltbresultados";
            this.ltbresultados.Size = new System.Drawing.Size(445, 346);
            this.ltbresultados.TabIndex = 1;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(606, 563);
            this.Controls.Add(this.ltbresultados);
            this.Controls.Add(this.btnexecutar);
            this.Name = "Form1";
            this.Text = "Campeonato";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnexecutar;
        private System.Windows.Forms.ListBox ltbresultados;
    }
}

